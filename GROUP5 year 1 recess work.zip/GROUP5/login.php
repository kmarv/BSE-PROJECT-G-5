
<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" href="style1.css" type="text/css" />


</head>
<body>
	<section id="content" class="column-right">
	<article>
	<fieldset>

					<legend>login</legend>
	<form action="http://localhost/GROUP5/welcome.php" method="post">
		<table>
			
			<tr>
				<td>Username:</td>
				<td><input type="text" name="uname"></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input type="password" name="pwd"></td>
				</tr>
				<tr>
					<td align="right" colspan="2"><input type="submit" name="login" class="formbutton" value="login"></td>
				</tr>
	

</table>
</fieldset>
</form>
</article>
</section>

</body>
</html>
steps
1 : gcc client.c
2 : gcc -o log login.c
3: gcc -o ser server.c
4 : ./ser
5 : ./log

register or login with 
username = lib
password = lubwama1